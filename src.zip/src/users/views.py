#All views defined and rendered by djoser
