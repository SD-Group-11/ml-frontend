from django.contrib import admin
from .models import TrainedModel

# Register your models here.
admin.site.register(TrainedModel)
