<template>
    <section class="hero is-light">
      <div class="hero-head"></div>
      <div class="hero-body">
          <header id="showcase" >
            <h1><strong>Machine Learning Front-End Framework</strong></h1>
            <p>Recently machine learning models have become popular at performing automatic classification. However, researchers have to constantly code up the training procedure of common networks such as Resnet or Alexnet which can be tedious. We can streamline this process by providing a frontend application where the user can choose an existing network and specify the classification task. The user should be able to construct a data pipeline, be able to download their trained models and test pre-trained models within application.</p>
          </header>
      </div>
      <div class="hero-foot"></div>
    </section>
</template>>

<style scoped>
  @import '../../assets/styles/homepage.css';
</style>



<script>
export default {
    name: "Dashboard"
}
</script>