# Machine Learning Front-End Framework
#[![Build Status](https://travis-ci.com/SD-Group-11/ml-frontend.svg?branch=main)](https://travis-ci.com/SD-Group-11/ml-frontend)
#[![codecov](https://codecov.io/gh/SD-Group-11/ml-frontend/branch/djoser-rehash/graph/badge.svg?token=VQH1ZCV2HT)](https://codecov.io/gh/SD-Group-11/ml-frontend)
