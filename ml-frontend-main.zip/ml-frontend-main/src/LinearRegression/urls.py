from django.urls import path

# from .views import(
#     # uploadResults,
#     # runLR,
# ) 

app_name ='LinearRegression'
## we're just creating the urls the data should be sent to for the respective processes in the view
urlpatterns =[
    # path('runLR',runLR,name='runLR'),
    # path('uploadResults',uploadResults,name='uploadResults')
]