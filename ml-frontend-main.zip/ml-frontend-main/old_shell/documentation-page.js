const backButton = document.getElementById("back-button");


backButton.addEventListener("click",(e) =>{
    e.preventDefault();
    location.href="home.html";
})